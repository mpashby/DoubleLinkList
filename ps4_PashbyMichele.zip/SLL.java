/* Michele Pashby
 * 30335753
 * mpashby19@cmc.edu
 */

public class SLL<T extends Comparable<T>> implements MyList<T> {
	Node<T> head;
	Node<T> tail;
	int size;

	public SLL() {
		head = null;
		size = 0;
	}
	
	// O(1)
	public boolean isEmpty() {
		if (head == null) {
			return true;
		}
		return false; 
	}
	
	// O(n)
	public int size() {
		Node<T> temp = head;
		return sizeAux(temp, 0);
	}
	//O(N)
	public int sizeAux(Node<T> temp, int count) {
		if (temp == null) {
			return count;
		} else  {
			return sizeAux(temp.getNext(), count+1);
		}
	}

	// O(1)
	public void addFirst(Object newData) {
		Node<T> newNode = new Node<T>(newData);
		newNode.setNext(head); 
	   	head = newNode;
	   	size++;
	   	if (newNode.getNext() == null) {
	   		tail = newNode;
	   	}
	   	
	}
	
	// O(N)
	public void add (T newData) {
		if(head == null || head.getData().compareTo(newData) > 0 ) {
		 	addFirst(newData);
		 	return;
		}
		Node<T> newNode = new Node<T>(newData);
		Node<T> current = head;
		while(current.getNext() != null && ((Comparable<T>) current.getNext().getData()).compareTo((T) newNode.getData()) < 0) {
			current = current.getNext();
		}
		newNode.setNext(current.getNext());
		current.setNext(newNode);
		if (newNode.getNext() == null) {
	   		tail = newNode;
		}
		size++;
	}
	
	// O(n)
	public Node<T> getNth(int n) {
		if (size == 0) {      // empty linked list
			return null;
		} else if (size < n) { // index number is larger than size
			Node<T> last = tail;
			return last;  // returns last node
		} else {
			Node<T> temp = head;
			return getNthAux(temp, n);
		}
	}
	
	// O(n)
	public Node<T> getNthAux(Node<T> thisNode, int n) {  // Auxiliary function for getNth
		if (n<=0) { 
			return thisNode;
		} else {
			return getNthAux(thisNode.getNext(), n-1);
		}
	}
	
	// O(n)
	@Override
	public int remove(Object removeData) {
		for (Node<T> current = head; current.getNext() != null; current = current.getNext()) {
			if (current.getData() == (T) removeData) {  // if this is the right node
				int ind = indexOf((T) current.getData());    // finds index
				Node<T> prev = getNth(ind-1);     // retrieves previous node
				prev.setNext(current.getNext());  // sets nodes to skip current
				current = null;         //delete element
				size--;
				return ind;
			}
		}
		return -1;  // not found on list
	}
	
	// O(1)
	@Override
	public int removeFirst() {
		if (size == 0) {
			throw new IllegalStateException("Empty List");  
		}
		Node<T> current = head;
		head = head.getNext();  // skips current head being removed
		current.setNext(null);
		size--;
		return (int) current.getData(); 
	}
	
	// O(n)
	@Override
	public int removeLast() {
		if (size == 0) {
			throw new IllegalStateException("Empty List");
		} else if (size == 1) {
			return removeFirst();
		} else {  			
			Node<T> previous = null;
			Node<T> current = head;
			while (current.getNext() != null) {  // up to last element on list
				previous = current;   // to get value before tail
				current = current.getNext();
			}
			previous.setNext(null);   // make this new tail
			tail = previous;
			size--;
			return (int) current.getData();
		}
	}
	
	// O(1)
	@Override
	public Node<T> getFirst() {
		if (isEmpty()) {
			throw new IllegalStateException("Empty List");
		}
		Node<T> first = head;
		return first;
	}
	
	// O(1)
	@Override
	public Node<T> getLast() {
		if (isEmpty()) {
			throw new IllegalStateException("Empty List");
		}
		Node<T> last = tail;
		return last;
	}
	
	// O(n)
	@Override
	public void print() {
		if(head == null)
			return;
		Node<T> current = head;
		
		while(current != null) {
			System.out.println("** " + current.toString());
			current = current.getNext();
		}
		System.out.println();	
	}
	
	// O(n)
	@Override
	public int indexOf(T newData) {
		Node<T> temp = head;
		return indexofAux(temp, newData, 0);
	}
	
	//O(N)
	public int indexofAux (Node<T> temp, T newData, int index) {  // index of helper funciton
	    if (temp == null) {  // reaches end of list
	    	return -1;
	    }
		else if (temp.getData() == newData) {
			return index;
		} else {
			return indexofAux (temp.getNext(), newData, index+1);
		}
	}
	
	// O(n)
	@Override
	public void removeDuplicates() {
		if (isEmpty()) {
			throw new IllegalStateException("Empty");
		} 
		Node<T> current = head;
		while (current.getNext() != null) {  // while not at end of list
			Node<T> nextNode = current.getNext();
			if (current.getData() == nextNode.getData()) {		
				remove(current.getData());
				size--;
			}
			current = current.getNext();
		}
	}
	
	//O(N)
	@Override
	public Node<T> shuffleMerge(SLL ll2) {
		//Node<T> current2 = ll2.getHead();
		for (Node<T> current2 = ll2.getFirst(); current2 != null; current2 = current2.getNext()) {
			add(current2.getData()); // combines list 2 into first one
		} 
		return this.head;
	}    	

}
