/* Michele Pashby
 * 30335753
 * mpashby19@cmc.edu
 */

public class UseSLL {

	public static void main(String args[]) {
		SLL L = new SLL();
		System.out.println("Add:  ");
		L.add(3);
		L.add(5);
		L.add(7);
		L.add(2);
		
		L.print();
		L.addFirst(2);
		System.out.println("Add First: ");
		L.print();
		L.removeFirst();
		System.out.println("Remove First ");
		L.print();
		L.removeLast();
		System.out.println("Remove Last: ");
		L.print();
		L.add(6);
		L.print();
		System.out.println("Remove: ");
		L.remove(2);
		L.print();
		System.out.println("Size: "+L.size());
		System.out.println("Get Nth: "+L.getNth(2));
		System.out.println("Index of: "+L.indexOf(5));
		
		SLL L2 = new SLL();
		L2.add(9);
		L2.add(3);
		L2.add(1);
		L2.add(8);
		System.out.println("Second List: ");
		L2.print();
		System.out.println("Get First: "+ L2.getFirst().toString());
		System.out.println("Get Last: "+ L2.getLast().toString());
		System.out.println("Shuffle Merge: "+ L.shuffleMerge(L2));
		L.print();
		System.out.println("Remove Duplicates: ");
		L.removeDuplicates();
		L.print();
		
	}
}
